
from Crypto.Util.number import getStrongPrime, getRandomRange, getRandomNBitInteger, getPrime
from collections import namedtuple
from sympy.ntheory import sqrt_mod
Point = namedtuple('Point', ['x', 'y'])

class EEPKC:
    def __init__(self, BITS = 512) -> None:
        assert BITS >= 512
        self.p =  getStrongPrime(BITS)
        self.A =  getRandomRange(0, self.p)
        self.B =  getPrime(256)
        def getGenerator():
            x = getRandomRange(0, self.p)
            y = None
            while y == None:
                y = sqrt_mod(x**3 + self.A*x + self.B, self.p)
            return Point(x, y)
        self.P = getGenerator()
        self._private = getRandomNBitInteger(BITS)
        self.public = self.getKey()['public']

    def getKey(self) -> dict:
        return {
            'public': self.mul(self.P, self._private),
            'p': self.p,
            'A': self.A,
            'B': self.B
        }

    def encrypt(self, M: Point):
        k = getRandomNBitInteger(512)
        C1 = self.mul(self.P, k)
        C2 = self.add(M, self.mul(self.public, k))
        return C1, C2

    def add(self, P: Point, Q: Point) -> Point:
        if P.x == Q.x and P.y == Q.y:
            y_diff = (3 * (P.x**2) + self.A) % self.p
            x_diff = (2 * P.y) % self.p
            slope = (y_diff * pow(x_diff, -1, self.p)) % self.p
            v = (P.y - slope * P.x) % self.p
            x3 = (slope**2 - P.x - Q.x) % self.p
            y3 = -(slope*x3 + v) % self.p
            return Point(x3, y3)
        else:
            y_diff = (Q.y - P.y) % self.p
            x_diff = (Q.x - P.x) % self.p
            slope = (y_diff * pow(x_diff, -1, self.p)) % self.p
            v = (P.y - slope * P.x) % self.p
            x3 = (slope**2 - P.x - Q.x) % self.p
            y3 = -(slope*x3 + v) % self.p
        return Point(x3, y3)

    def mul(self, P: Point, n: int) -> Point:
        Q = P
        R = Point(0, 0)
        while n > 0:
            if n & 1 == 1:
                if R.x == 0 and R.y == 0:
                    R = Q
                else:
                    R = self.add(R, Q)
            Q = self.add(Q, Q)
            n //= 2
        return R
