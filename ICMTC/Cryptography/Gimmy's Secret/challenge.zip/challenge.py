#!/bin/bash/env python3
from Cipher import EEPKC, Point
from Crypto.Util.number import bytes_to_long
from secret import FLAG, getY

if __name__ == '__main__':
    obj = EEPKC()
    key = obj.getKey()
    p = key['p']
    A = key['A']
    B = key['B']
    x = bytes_to_long(FLAG)
    
    M = Point(x, getY(x, A, B, p))

    C1, C2 = obj.encrypt(M)
    key.update({"C1.y": C1.y, "C2.y": C2.y, "private": obj._private})
    print(key)
